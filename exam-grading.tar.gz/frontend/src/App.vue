<script setup>
import { RouterLink, RouterView } from 'vue-router'
</script>

<template>
  <el-container style="min-height: 100vh">
    <el-header style="background: #409eff; color: #fff; display: flex; align-items: center;">
      <h2 style="margin: 0; font-size: 18px;">📝 试卷阅卷打分系统</h2>
      <el-menu
        :default-active="$route.path"
        mode="horizontal"
        background-color="#409eff"
        text-color="#fff"
        active-text-color="#fff"
        router
        style="margin-left: 40px; border: none; flex: 1;"
      >
        <el-menu-item index="/scan">扫描判分</el-menu-item>
        <el-menu-item index="/papers">试卷管理</el-menu-item>
      </el-menu>
      <el-tag type="warning" size="small" effect="dark">第1期 MVP</el-tag>
    </el-header>

    <el-main>
      <RouterView />
    </el-main>
  </el-container>
</template>

<style>
body {
  margin: 0;
  font-family: -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif;
  background: #f5f7fa;
}
</style>
