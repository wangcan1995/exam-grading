<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { paperApi, statApi } from '../api'

const papers = ref([])
const dialogVisible = ref(false)
const form = ref({ name: '', subject: '', grade: '', description: '' })

// 简化创建: 暂时只填基础信息，模板通过 API/脚本配置
// (完整可视化模板编辑器是第 4 期功能)

onMounted(load)

async function load() {
  const { data } = await paperApi.list()
  papers.value = data
}

async function handleCreate() {
  if (!form.value.name) {
    ElMessage.warning('请填写试卷名称')
    return
  }
  try {
    await paperApi.create({ ...form.value, template_json: [] })
    ElMessage.success('试卷已创建(需后续配置答题卡模板)')
    dialogVisible.value = false
    form.value = { name: '', subject: '', grade: '', description: '' }
    await load()
  } catch (e) {
    ElMessage.error('创建失败: ' + (e.response?.data?.detail || e.message))
  }
}

async function handleDelete(id) {
  await ElMessageBox.confirm('确定删除该试卷？关联的答题卡记录也会一并删除', '确认', {
    type: 'warning',
  })
  await paperApi.delete(id)
  ElMessage.success('已删除')
  await load()
}

async function viewStats(id) {
  try {
    const { data } = await statApi.paper(id)
    const msg = data.count === 0
      ? '该试卷暂无判分数据'
      : `人数: ${data.count} | 平均分: ${data.average} | 最高: ${data.max_score} | 最低: ${data.min_score} | 及格率: ${(data.pass_rate*100).toFixed(0)}%`
    ElMessageBox.alert(msg, `${data.paper_name} - 成绩统计`)
  } catch (e) {
    ElMessage.error('查询统计失败')
  }
}
</script>

<template>
  <el-card>
    <template #header>
      <div style="display:flex; justify-content:space-between; align-items:center;">
        <strong>试卷管理</strong>
        <el-button type="primary" @click="dialogVisible = true">+ 新建试卷</el-button>
      </div>
    </template>

    <el-table :data="papers" stripe>
      <el-table-column prop="id" label="ID" width="60" />
      <el-table-column prop="name" label="试卷名称" />
      <el-table-column prop="subject" label="学科" width="100" />
      <el-table-column prop="grade" label="年级" width="100" />
      <el-table-column prop="question_count" label="题目数" width="90" />
      <el-table-column prop="total_score" label="满分" width="80" />
      <el-table-column label="操作" width="200">
        <template #default="{ row }">
          <el-button size="small" @click="viewStats(row.id)">统计</el-button>
          <el-button size="small" type="danger" @click="handleDelete(row.id)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-alert
      style="margin-top: 16px;"
      type="info" :closable="false"
      title="提示: 答题卡模板(选项坐标)目前通过脚本生成，可视化编辑器将在第 4 期实现。"
    />
  </el-card>

  <!-- 新建试卷对话框 -->
  <el-dialog v-model="dialogVisible" title="新建试卷" width="480px">
    <el-form :model="form" label-width="90px">
      <el-form-item label="试卷名称">
        <el-input v-model="form.name" placeholder="例: 2025期中数学" />
      </el-form-item>
      <el-form-item label="学科">
        <el-input v-model="form.subject" placeholder="选填" />
      </el-form-item>
      <el-form-item label="年级">
        <el-input v-model="form.grade" placeholder="选填" />
      </el-form-item>
      <el-form-item label="描述">
        <el-input v-model="form.description" type="textarea" :rows="2" />
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="dialogVisible = false">取消</el-button>
      <el-button type="primary" @click="handleCreate">创建</el-button>
    </template>
  </el-dialog>
</template>
