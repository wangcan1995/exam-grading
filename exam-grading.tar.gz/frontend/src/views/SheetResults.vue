<script setup>
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'
import { scanApi } from '../api'

const route = useRoute()
const sheetId = Number(route.params.id)

const sheet = ref(null)
const results = ref([])
const loading = ref(true)
const imageTab = ref('original')

onMounted(loadData)

async function loadData() {
  loading.value = true
  try {
    const [s, r] = await Promise.all([
      scanApi.getSheet(sheetId),
      scanApi.getResults(sheetId),
    ])
    sheet.value = s.data
    results.value = r.data
  } catch (e) {
    ElMessage.error('加载失败: ' + (e.response?.data?.detail || e.message))
  } finally {
    loading.value = false
  }
}

// fill_ratio → 进度条百分比
function fillPercent(detail, option) {
  const o = detail?.options?.find((x) => x.option === option)
  return o ? Math.round(o.fill_ratio * 100) : 0
}
</script>

<template>
  <div v-loading="loading">
    <el-page-header @back="$router.push('/scan')" content="判分结果详情" style="margin-bottom: 20px;" />

    <el-row :gutter="20" v-if="sheet">
      <!-- 左侧: 图片对比 -->
      <el-col :span="14">
        <el-card>
          <template #header>
            <strong>答题卡图像</strong>
          </template>
          <el-tabs v-model="imageTab">
            <el-tab-pane label="原始图" name="original">
              <img
                v-if="sheet.original_path"
                :src="scanApi.imageUrl(sheet.id, 'original')"
                style="width: 100%; border: 1px solid #eee;"
              />
            </el-tab-pane>
            <el-tab-pane label="矫正后" name="processed">
              <img
                v-if="sheet.processed_path"
                :src="scanApi.imageUrl(sheet.id, 'processed')"
                style="width: 100%; border: 1px solid #eee;"
              />
              <el-alert
                v-else type="info" :closable="false"
                title="尚未生成矫正图"
              />
            </el-tab-pane>
          </el-tabs>
        </el-card>
      </el-col>

      <!-- 右侧: 判分汇总 -->
      <el-col :span="10">
        <el-card>
          <template #header><strong>判分汇总</strong></template>
          <el-descriptions :column="1" border>
            <el-descriptions-item label="学生">
              {{ sheet.student_name || sheet.student_id || '-' }}
            </el-descriptions-item>
            <el-descriptions-item label="状态">
              <el-tag :type="sheet.status === 'graded' ? 'success' : 'warning'" size="small">
                {{ sheet.status }}
              </el-tag>
            </el-descriptions-item>
            <el-descriptions-item label="总分">
              <span style="font-size: 24px; color: #409eff; font-weight: bold;">
                {{ sheet.total_score }}
              </span>
            </el-descriptions-item>
            <el-descriptions-item label="是否需复核">
              <el-tag :type="sheet.needs_review ? 'warning' : 'success'" size="small">
                {{ sheet.needs_review ? '有题需复核' : '全部自动判分' }}
              </el-tag>
            </el-descriptions-item>
            <el-descriptions-item label="判分时间">
              {{ sheet.graded_at ? new Date(sheet.graded_at).toLocaleString('zh-CN') : '-' }}
            </el-descriptions-item>
          </el-descriptions>
        </el-card>
      </el-col>
    </el-row>

    <!-- 逐题判分明细 -->
    <el-card style="margin-top: 20px;">
      <template #header><strong>逐题判分明细</strong></template>
      <el-table :data="results" stripe>
        <el-table-column prop="question_no" label="题号" width="70" />
        <el-table-column label="学生答案" width="110">
          <template #default="{ row }">
            <strong>{{ row.detected_answer || '∅(未涂)' }}</strong>
          </template>
        </el-table-column>
        <el-table-column prop="correct_answer" label="标准答案" width="100" />
        <el-table-column label="结果" width="80">
          <template #default="{ row }">
            <el-tag :type="row.final_score >= row.max_score ? 'success' : 'danger'" size="small">
              {{ row.final_score >= row.max_score ? '✓ 对' : '✗ 错' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="得分" width="100">
          <template #default="{ row }">
            {{ row.final_score }} / {{ row.max_score }}
          </template>
        </el-table-column>
        <el-table-column label="置信度" width="160">
          <template #default="{ row }">
            <el-progress
              :percentage="Math.round(row.confidence * 100)"
              :status="row.confidence > 0.8 ? 'success' : 'warning'"
            />
          </template>
        </el-table-column>
        <el-table-column label="各选项涂卡比例" min-width="280">
          <template #default="{ row }">
            <div v-for="opt in row.detail?.options || []" :key="opt.option" style="display:flex; align-items:center; gap:8px; margin-bottom:2px;">
              <span style="width:16px; font-weight:bold; color:#606266;">{{ opt.option }}</span>
              <el-progress
                :percentage="Math.round(opt.fill_ratio * 100)"
                :stroke-width="10"
                style="flex:1;"
                :show-text="false"
                :color="opt.marked ? '#67c23a' : '#dcdfe6'"
              />
              <span style="width:36px; font-size:12px; color:#909399;">
                {{ Math.round(opt.fill_ratio * 100) }}%
              </span>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="复核" width="100">
          <template #default="{ row }">
            <el-tag v-if="row.needs_review" type="warning" size="small">待复核</el-tag>
            <span v-else style="color:#67c23a;">自动通过</span>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>
