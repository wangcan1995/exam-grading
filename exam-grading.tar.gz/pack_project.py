#!/usr/bin/env python3
"""Pack the project into a tar.gz, excluding large/unnecessary dirs."""
import tarfile
import os
import sys

PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_FILE = os.path.join(PROJECT_DIR, "exam-grading.tar.gz")

EXCLUDE_DIRS = {
    "node_modules", ".venv", "__pycache__", ".git",
    "venv", "env", ".idea", ".vscode"
}
EXCLUDE_FILES = {
    "exam_grading.db", "deploy_ssh.py", "test_ssh.py",
    "ssh_debug.txt", "daemon.json", "exam-grading.tar.gz",
    "package-lock.json"
}
EXCLUDE_PATTERNS = [".pyc", ".pyo"]

def should_exclude(name):
    if name in EXCLUDE_DIRS or name in EXCLUDE_FILES:
        return True
    for pat in EXCLUDE_PATTERNS:
        if name.endswith(pat):
            return True
    return False

def add_dir(tar, path, arcname=""):
    for item in os.listdir(path):
        if should_exclude(item):
            continue
        full_path = os.path.join(path, item)
        rel_path = os.path.join(arcname, item) if arcname else item
        if os.path.isdir(full_path):
            # Skip storage uploads/processed contents but keep .gitkeep
            if item == "storage":
                add_dir(tar, full_path, rel_path)
            else:
                add_dir(tar, full_path, rel_path)
        elif os.path.isfile(full_path):
            # Skip uploaded images in storage
            if "storage" in full_path and (".png" in item or ".jpg" in item):
                continue
            tar.add(full_path, arcname=rel_path)

def main():
    print(f"Packing project from {PROJECT_DIR} ...")
    with tarfile.open(OUTPUT_FILE, "w:gz") as tar:
        add_dir(tar, PROJECT_DIR)
    
    size_mb = os.path.getsize(OUTPUT_FILE) / (1024 * 1024)
    print(f"Done! Output: {OUTPUT_FILE} ({size_mb:.1f} MB)")

if __name__ == "__main__":
    main()
